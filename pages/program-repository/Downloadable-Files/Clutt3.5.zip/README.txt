CLUTT3.5 (REMAKE)
-----------------------------------------------------------------------------------
Created by: CYBER SOLDIER(Clutter)
Type of malware: gdi trojan
Destructive: Of course it's a clutt
Programming language: C#
Os support: I recommend running on windows xp or windows 7 without the aero effect! 
Payloads can be slow on newer operating systems!
Required components: NetFramework4.0
-----------------------------------------------------------------------------------
DO NOT UNDER ANY CIRCUMSTANCES RUN THIS MALWARE ON A REAL DEVICE!
THIS PROGRAM CAN DAMAGE ALL YOUR DATA!
PLEASE TEST EVERYTHING ON A VIRTUAL MACHINE!
I AM NOT RESPONSIBLE FOR ANY DAMAGES!!!
-----------------------------------------------------------------------------------