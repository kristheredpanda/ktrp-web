This .zip was created so that you can run my malware 'furryvirus.exe' on an operating system as old as Windows Vista,
it will not work on Windows XP as .NET Framework 4.5.1 does not support that operating system.
===========================================================================================================================
Compatiable Versions:
Windows 10 (framework installer not needed as this framework version is built into Windows 10)
Windows 8.1
Windows 8
Windows 7
Windows Vista
===========================================================================================================================
Made by: Sky The Foxx